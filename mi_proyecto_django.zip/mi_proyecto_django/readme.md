# Mi Proyecto Django

Este proyecto es una aplicación web en Django que demuestra el uso del patrón MVT, herencia de plantillas HTML, definición de modelos con relaciones, formularios para inserción de datos y un formulario de búsqueda.

De acuerdo a:

Consigna

Crea una web en Django utilizando Herencia de plantillas, con un modelo de por lo menos 3 clases (*Creado Clase Pais, Clase Ciudad, Clase Cliente).
Un formulario para ingresar datos a las 3 clases (*)
un formulario para buscar algo en la BD, no hace falta que sea sobre las tres clases, con realizar búsqueda sobre una alcanzará.(*)

Te sugerimos que hagas  una web estilo blog para ir preparando en la entrega final.

Objetivos

    Desarrollar tu primer WEB en Django utilizando patrón MVT

Requisitos

    Link de GitHub con el proyecto totalmente subido a la plataforma.

    Proyecto Web Django con patrón MVT que incluya:

        Herencia de HTML. (*)


        Por lo menos 3 clases en models.(*Clase Pais, Clase Ciudad, Clase Cliente)

        Un formulario para insertar datos por cada model creado.(*)

        Un formulario para buscar algo en la BD (*)

        Readme que indique el orden en el que se prueban las cosas y/o donde están las funcionalidades. (*)

Formato

Link al repositorio de GitHub con el nombre “TuPrimeraPagina+Apellido”  por ejemplo “TuPrimeraPagina+Fernandez”

## Estructura del Proyecto

mi_proyecto_django/
├── venv/                      # Entorno virtual
├── mi_web/                    # Configuración del proyecto Django
│   ├── init.py
│   ├── asgi.py
│   ├── settings.py            # Configuración principal de Django
│   ├── urls.py                # URLs principales del proyecto
│   └── wsgi.py
├── principal/                 # Aplicación Django principal
│   ├── migrations/
│   ├── init.py
│   ├── admin.py
│   ├── apps.py
│   ├── models.py              # Definición de las clases (Pais, Ciudad, Cliente)
│   ├── tests.py
│   ├── views.py               # Lógica de las vistas
│   ├── forms.py               # Definición de los formularios
│   └── templates/
│       └── principal/         # Plantillas HTML
│           ├── base.html      # Plantilla base para herencia
│           ├── inicio.html
│           ├── crear_pais.html
│           ├── listar_paises.html
│           ├── crear_ciudad.html
│           ├── listar_ciudades.html
│           ├── crear_cliente.html
│           ├── listar_clientes.html
│           └── buscar_cliente.html
├── manage.py                  # Utilidad para administrar el proyecto Django
└── requirements.txt           # Dependencias del proyecto
└── README.md                  # Este archivo



## Configuración y Ejecución

Sigue estos pasos para configurar y ejecutar el proyecto:

1.  **Clonar el repositorio o crear la carpeta:**
    Si estás creando el proyecto desde cero, primero crea la carpeta `mi_proyecto_django`.

2.  **Abrir en Visual Studio Code:**
    Abre la carpeta `mi_proyecto_django` en Visual Studio Code.

3.  **Crear y Activar el Entorno Virtual:**
    ejecuta: python -m venv venv
    Para activar: .\venv\Scripts\activate
    Verifica que `(venv)` aparezca al inicio de tu línea de comandos.

4.  **Instalar Dependencias:**
    pip install -r requirements.txt

5.  **Realizar Migraciones de Base de Datos:**
    python manage.py makemigrations
    python manage.py migrate

6.  **Crear un Superusuario (Opcional, para acceder al panel de administración de Django):**
    python manage.py createsuperuser
    Sigue las instrucciones para crear tu usuario y contraseña.

7.  **Ejecutar el Servidor de Desarrollo:**
    python manage.py runserver


## Funcionalidades y Dónde Encontrarlas

* **Página de Inicio:**
    * Acceso: http://127.0.0.1:8000/
      El servidor se ejecutará en http://127.0.0.1:8000/ o http://localhost:8000/
    * Archivo: `principal/templates/principal/inicio.html`

* **Como recorrer:**
    * Una opcion de recorrer puede ser ir a la barra de herramientas situada en la parte superior y seleccionar:
        - Inicio: La pagina inicial que se observa al entrar
        - Listar paises: Veremos los paises que tenemos cargados en la base de datos
        - Listar ciudades: Veremos las ciudades cargadas en la base de datos y sus respectivos paises
        - Listar clientes: Veremos los clientes cargados en la base de datos
        - Crear pais: Crearemos un nuevo acceso a la base de datos. Colocamos el nombre del pais y seleccionamos guardar el pais. Luego mostrara los paises cargados.
        - Crear ciudad: Crearemos una nueva ciudad en la base de datos y nos permitira colocar el pais. Seleccioanmos guardar.  Luego Mostrara los paises cargados.
        - Crear cliente: Crearemmos un nuevo cliente en la base de datos y nos permitira colocar nombre, apellido, fecha de nacimiento, pais y ciudad.
        - Buscar Cliente: Nos visualizara en la parte inferior la base de datos del cliente y tendremos un campo donde colocar nombre o apellido o parte de alguno
          de esos datos y nos traera las coincidencias con la busqueda. Para realizar la busqueda hay que presionar el boton buscar.


* **Formularios para cear datos:**
    * **País:**
        * Crear pais
        * Crear: http://localhost:8000/paises/crear/
        * Archivos: principal/forms.py (PaisForm), principal/views.py (crear_pais), principal/templates/principal/crear_pais.html

    * **Ciudad:**
        * Crear ciudad
        * Crear: http://localhost:8000/ciudades/crear/
        * Archivos: principal/forms.py (CiudadForm), principal/views.py (crear_ciudad), principal/templates/principal/crear_ciudad.html

    * **Cliente:**
        * Crear cliente
        * Crear: http://localhost:8000/clientes/crear/
        * Archivos: principal/forms.py (ClienteForm), principal/views.py (crear_cliente), principal/templates/principal/crear_cliente.html

* **Listado de Datos:**
    *    * Listar paises
         - URL: http://localhost:8000/paises/

    *    * Listar ciudades
         - URL: http://localhost:8000/ciudades/
      
    *    * Listar clientes
         - URL: http://localhost:8000/clientes/

* **Formulario de búsqueda de clientes:**
    *    * Buscar clientes
         - URL: http://localhost:8000/clientes/buscar/
         * Archivos: principal/forms.py (BuscarClienteForm), principal/views.py (buscar_cliente), principal/templates/principal/buscar_cliente.html

* **Modelos definidos:**
    * Definidos en principal/models.py (Clase Pais, Clase Ciudad, Clase Cliente).

* **Herencia HTML:**
    * La plantilla base se encuentra en principal/templates/principal/base.html.
    * Todas las demás plantillas (crear_pais.html, listar_paises.html, etc.) extienden de base.html utilizando extends principal/base.html.

* **Panel de Administración de Django (Opcional):**
    * Acceso: http://localhost:8000/admin
      - Falta crear superusuario con python manage.py createsuperuser

## Consideraciones Adicionales

* Este proyecto utiliza una base de datos SQLite
* La interfaz de usuario es básica, diseñada para demostrar las funcionalidades de Django.
