# para sacar el warning del from
from django.db.models import Q
from django.shortcuts import render, redirect
# Importamos las vistas de la aplicación principal
from .forms import PaisForm, CiudadForm, ClienteForm, BuscarClienteForm
from .models import Pais, Ciudad, Cliente
#from django.db.models import Q # Para búsquedas OR

def inicio(request):
    """Vista para la página de inicio."""
    return render(request, 'principal/inicio.html')

def crear_pais(request):
    """Vista para crear un nuevo país."""
    if request.method == 'POST':
        form = PaisForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_paises')
    else:
        form = PaisForm()
    return render(request, 'principal/crear_pais.html', {'form': form})

def listar_paises(request):
    """Vista para listar todos los países."""
    paises = Pais.objects.all()
    return render(request, 'principal/listar_paises.html', {'paises': paises})

def crear_ciudad(request):
    """Vista para crear una nueva ciudad."""
    if request.method == 'POST':
        form = CiudadForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_ciudades')
    else:
        form = CiudadForm()
    return render(request, 'principal/crear_ciudad.html', {'form': form})

def listar_ciudades(request):
    """Vista para listar todas las ciudades."""
    ciudades = Ciudad.objects.all()
    return render(request, 'principal/listar_ciudades.html', {'ciudades': ciudades})

def crear_cliente(request):
    """Vista para crear un nuevo cliente."""
    if request.method == 'POST':
        form = ClienteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_clientes')
    else:
        form = ClienteForm()
    return render(request, 'principal/crear_cliente.html', {'form': form})

def listar_clientes(request):
    """Vista para listar todos los clientes."""
    clientes = Cliente.objects.all()
    return render(request, 'principal/listar_clientes.html', {'clientes': clientes})

def buscar_cliente(request):
    """Vista para buscar clientes por nombre o apellido."""
    form = BuscarClienteForm(request.GET or None)
    clientes = Cliente.objects.all()
    if form.is_valid():
        nombre_buscado = form.cleaned_data.get('nombre')
        if nombre_buscado:
            clientes = clientes.filter(Q(nombre__icontains=nombre_buscado) | Q(apellido__icontains=nombre_buscado))
    return render(request, 'principal/buscar_cliente.html', {'form': form, 'clientes': clientes})