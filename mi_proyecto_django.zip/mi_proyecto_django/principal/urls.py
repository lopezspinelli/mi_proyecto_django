from django.urls import path
# Importamos las vistas que hemos creado
from . import views
# Importamos las vistas de la aplicación principal

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('paises/crear/', views.crear_pais, name='crear_pais'),
    path('paises/', views.listar_paises, name='listar_paises'),
    path('ciudades/crear/', views.crear_ciudad, name='crear_ciudad'),
    path('ciudades/', views.listar_ciudades, name='listar_ciudades'),
    path('clientes/crear/', views.crear_cliente, name='crear_cliente'),
    path('clientes/', views.listar_clientes, name='listar_clientes'),
    path('clientes/buscar/', views.buscar_cliente, name='buscar_cliente'),
]
