"""This module defines the models for the application, including Pais, Ciudad, and Cliente."""
from django.db import models
# modelos

class Pais(models.Model):
    """Modelo para representar un país."""
    nombre_pais = models.CharField(max_length=100, unique=True)

    def __str__(self):
        #return self.nombre_pais
        return f"{self.nombre_pais}"

    class Meta:
        """Meta class to define additional options for the model."""
        verbose_name_plural = "Países"

class Ciudad(models.Model):
    """Modelo para representar una ciudad."""
    nombre_ciudad = models.CharField(max_length=100)
    pais_origen = models.ForeignKey(Pais, on_delete=models.CASCADE, related_name='ciudades')

    def __str__(self):
        return f"{self.nombre_ciudad}"# ({self.pais_origen.nombre_pais})"

    class Meta:
        """Meta class to define additional options for the model."""
        verbose_name_plural = "Ciudades"
        unique_together = ('nombre_ciudad', 'pais_origen')

class Cliente(models.Model):
    """Modelo para representar un cliente."""
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    fecha_nacimiento = models.DateField()
    pais = models.ForeignKey(Pais, on_delete=models.SET_NULL, null=True, blank=True)
    ciudad = models.ForeignKey(Ciudad, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return f"{self.nombre} {self.apellido}"

    class Meta:
        """Meta class to define additional options for the model."""
        verbose_name_plural = "Clientes"