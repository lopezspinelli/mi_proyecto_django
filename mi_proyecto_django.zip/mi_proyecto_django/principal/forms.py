from django import forms
# Importamos los modelos necesarios
from .models import Pais, Ciudad, Cliente
# Formularios para manejar los modelos de la aplicación

class PaisForm(forms.ModelForm):
    """Clase para crear un formulario de País."""
    #clase para crear un formulario de Pais
    class Meta:
        """Clase para crear un formulario de País."""
        model = Pais
        fields = ['nombre_pais']

class CiudadForm(forms.ModelForm):
    """Clase para crear un formulario de Ciudad."""
    class Meta:
        """"Clase para crear un formulario de Ciudad."""
        model = Ciudad
        fields = ['nombre_ciudad', 'pais_origen']

class ClienteForm(forms.ModelForm):
    """Clase para crear un formulario de Cliente."""
    class Meta:
        """Clase para crear un formulario de Cliente."""
        model = Cliente
        fields = ['nombre', 'apellido', 'fecha_nacimiento', 'pais', 'ciudad']
        widgets = {
            'fecha_nacimiento': forms.DateInput(attrs={'type': 'date'}),
        }

class BuscarClienteForm(forms.Form):
    """Formulario para buscar clientes por nombre."""
    nombre = forms.CharField(max_length=100, required=False, label="Nombre del Cliente")